import math
import multiprocessing
import os
import time
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import Adam
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch.utils.data import TensorDataset, DataLoader
from MyModel import MixedModel
from MyModel import CnnLSTM

PARAMETER_CONFIGURATION = {
    'input_size': 154,
    'num_classes': 21,
    'epochs': 5,
    'batch_size': 1024,
    'DataFolder': './Trained_Data',
    'Validation_Data': './Validation_Data',
    'testData': './Test_Data',
    'lr': 1e-3,
    'device': torch.device('cpu'),  # 设置为CPU
    'model_save_path': './TrainedModel',
    'training_data_path': r'../dataset/data/Training_Data',
    'testing_data_path': r'../dataset/data/Testing_Data',
    'add_gaussian_noise_for_training': True,
    'add_gaussian_noise_for_testing': True,
    'K_value': 3,
    'oridinate_csv': './ordinate.csv'
}

def z_score_normalize(data):
    mean = np.mean(data,axis=0)
    std = np.std(data,axis=0)
    normalized_array = (data - mean) / std
    return normalized_array

def add_gaussian_noise(data, mean, std):
    noise = np.random.normal(mean, std, data.shape)
    noisy_data = data + noise
    return np.vstack((data, noisy_data))

def load_dataset_at(dataset_id, fold_index=PARAMETER_CONFIGURATION['DataFolder'], validation_set=True):
    X_train, y_train, X_test, y_test = [], [], [], []
    All_RP = ['A1', 'A2', 'A3', 'A4', 'B1', 'B2', 'B3', 'B4', 'C1', 'C2', 'C3', 'D1', 'D2', 'D3', 'D4', 'D5', 'E3', 'E4', 'F1', 'F3', 'F4']

    index = 0
    for test_RP in All_RP:
        dataset = []
        path_train = os.path.join( fold_index , test_RP )
        for file in os.listdir(path_train):
            file_path = os.path.join( path_train , f'{file}'   )
            single_RP_data = pd.read_csv( file_path )
            dataset.append( single_RP_data['RSS'] )
        dataset_train = np.array(dataset, dtype=np.float32)

        if validation_set:
            for i in range(8):
                dataset_train = add_gaussian_noise(dataset_train, 0, i / 2)

        X_train.append( dataset_train )
        y_train.append( [ All_RP.index(test_RP) ] * len(X_train[index]) )

        dataset = []
        path_validation = os.path.join( PARAMETER_CONFIGURATION['Validation_Data'] , test_RP )
        for file in os.listdir(path_validation):
            file_path = os.path.join( path_validation , f'{file}' )
            single_RP_data = pd.read_csv( file_path )
            dataset.append( single_RP_data['RSS'] )
        dataset_validation = np.array( dataset , dtype=np.float32 )

        if validation_set:
            for i in range(8):
                dataset_validation = add_gaussian_noise(dataset_validation, 0, i)
        X_test.append(dataset_validation)
        y_test.append( [ All_RP.index(test_RP) ] * len(X_test[index]))
        index = index + 1

    X_train, X_test = map(np.vstack, (X_train, X_test,))
    X_train, X_test = map(lambda x: np.expand_dims(x, 1), (X_train, X_test))
    y_train, y_test = map(np.hstack, (y_train, y_test))
    X_train, y_train, X_test, y_test = map(np.array, (X_train, y_train, X_test, y_test))

    return X_train, y_train, X_test, y_test

def load_test_data(dataset_id, fold_index=PARAMETER_CONFIGURATION['DataFolder'], validation_set=True):
    X_train, y_train, X_test, y_test = [], [], [], []
    All_RP = ['A1', 'A2', 'A3', 'A4', 'B1', 'B2', 'B3', 'B4', 'C1', 'C2', 'C3', 'D1', 'D2', 'D3', 'D4', 'D5', 'E3',
              'E4', 'F1', 'F3', 'F4']

    index = 0
    for test_RP in All_RP:
        dataset = []
        path_train = os.path.join(fold_index, test_RP)
        for file in os.listdir(path_train):
            file_path = os.path.join(path_train, f'{file}')
            single_RP_data = pd.read_csv(file_path)
            dataset.append(single_RP_data['RSS'])
        dataset_train = np.array(dataset, dtype=np.float32)

        if validation_set:
            for i in range(8):
                dataset_train = add_gaussian_noise(dataset_train, 0, i / 2)

        X_train.append(dataset_train)
        y_train.append([All_RP.index(test_RP)] * len(X_train[index]))

        dataset = []
        path_validation = os.path.join(PARAMETER_CONFIGURATION['testData'], test_RP)
        for file in os.listdir(path_validation):
            file_path = os.path.join(path_validation, f'{file}')
            single_RP_data = pd.read_csv(file_path)
            dataset.append(single_RP_data['RSS'])
        dataset_validation = np.array(dataset, dtype=np.float32)

        if validation_set:
            for i in range(5):
                dataset_validation = add_gaussian_noise(dataset_validation, 0, i / 2)
        X_test.append(dataset_validation)
        y_test.append([All_RP.index(test_RP)] * len(X_test[index]))
        index = index + 1

    X_train, X_test = map(np.vstack, (X_train, X_test,))
    X_train, X_test = map(lambda x: np.expand_dims(x, 1), (X_train, X_test))
    y_train, y_test = map(np.hstack, (y_train, y_test))
    X_train, y_train, X_test, y_test = map(np.array, (X_train, y_train, X_test, y_test))

    return X_train, y_train, X_test, y_test

def train_model(model, dataset_id, epochs=100, batch_size=128, learning_rate=1e-3,
                monitor='loss', device='cpu'):
    X_train, y_train, X_test, y_test = load_dataset_at(dataset_id)
    X_train, y_train, X_test, y_test = map(torch.tensor, (X_train, y_train, X_test, y_test))

    train_loader = DataLoader(TensorDataset(X_train, y_train), batch_size=batch_size, shuffle=True,
                              drop_last=True, num_workers=1)
    test_loader = DataLoader(TensorDataset(X_test, y_test), batch_size=batch_size, shuffle=True,
                             drop_last=False, num_workers=1)

    criterion = nn.CrossEntropyLoss()
    optimizer = Adam(model.parameters(), lr=learning_rate, weight_decay=1e-4)
    scheduler = ReduceLROnPlateau(optimizer, mode='min', factor=0.1, patience=10, verbose=True)

    for epoch in range(epochs):
        model.train()
        running_loss = 0.0
        correct_predictions = 0
        for inputs, labels in train_loader:
            inputs = inputs.float()
            labels = labels.long()
            optimizer.zero_grad()
            outputs = model(inputs)
            _, preds = torch.max(outputs, 1)

            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item() * inputs.size(0)
            correct_predictions += torch.sum(preds == labels.data)
        epoch_loss = running_loss / len(train_loader.dataset)
        epoch_acc = correct_predictions.double() / len(train_loader.dataset)

        model.eval()
        running_loss_val = 0.0
        correct_predictions_val = 0
        with torch.no_grad():
            for inputs, labels in test_loader:
                inputs = inputs.float()
                labels = labels.long()
                outputs = model(inputs)

                _, preds = torch.max(outputs, 1)
                loss = criterion(outputs, labels)
                running_loss_val += loss.item() * inputs.size(0)
                correct_predictions_val += torch.sum(preds == labels.data)
        epoch_loss_val = running_loss_val / len(test_loader.dataset)
        epoch_acc_val = correct_predictions_val.double() / len(test_loader.dataset)

        if monitor == 'loss':
            scheduler.step(epoch_loss_val)
        else:
            scheduler.step(epoch_acc_val)

        print(f'Epoch {epoch + 1}/{epochs}, Train Loss: {epoch_loss:.4f}, Train Acc: {epoch_acc:.4f}, '
              f'Val Loss: {epoch_loss_val:.4f}, Val Acc: {epoch_acc_val:.4f}')
        evaluate_model(model, dataset_id=dataset_id, batch_size=PARAMETER_CONFIGURATION['batch_size'],
                       validation_set=False)

    return model

def evaluate_model(model, dataset_id=1, fold_index=PARAMETER_CONFIGURATION['DataFolder'], batch_size=128, validation_set=True):
    _, _, X_test, y_test = load_test_data(dataset_id, validation_set=False)
    X_test, y_test = map(torch.tensor, (X_test, y_test))

    test_loader = DataLoader(TensorDataset(X_test, y_test), batch_size=batch_size, shuffle=False,
                             drop_last=False, num_workers=1, pin_memory=False)

    criterion = nn.CrossEntropyLoss()

    model.eval()
    running_loss = 0.0
    correct_predictions = 0

    with torch.no_grad():
        for inputs, labels in test_loader:
            inputs = inputs.float().to('cpu')
            labels = labels.long().to('cpu')
            outputs = model(inputs)
            _, preds = torch.max(outputs, 1)
            loss = criterion(outputs, labels)
            running_loss += loss.item() * inputs.size(0)
            correct_predictions += torch.sum(preds == labels.data)

    test_loss = running_loss / len(test_loader.dataset)
    test_acc = correct_predictions.double() / len(test_loader.dataset)

    print(f'Test Loss: {test_loss:.4f}, Test Accuracy: {test_acc:.4f}')

    return test_loss, test_acc

#ok

def process_dataset(Dataset_Id, Model, model_name):
    # 将模型移到 CPU
    device = torch.device('cpu')
    Model = Model.to(device)

    model_path = os.path.join(PARAMETER_CONFIGURATION['model_save_path'], model_name)
    '''
    if os.path.exists(model_path):
          # 加载模型状态字典
        state_dict = torch.load(model_path, map_location=device)
        
        # 处理 DataParallel 的情况
        if 'module.' in list(state_dict.keys())[0]:
            state_dict = {key.replace('module.', ''): value for key, value in state_dict.items()}
        
        # 加载状态字典到模型
        Model.load_state_dict(state_dict)
    else:'''
    Model = train_model(model=Model, dataset_id=Dataset_Id,
                            epochs=PARAMETER_CONFIGURATION['epochs'],
                            batch_size=PARAMETER_CONFIGURATION['batch_size'],
                            device=device,  # 将设备设为 CPU
                            learning_rate=PARAMETER_CONFIGURATION['lr'])
        # 保存模型
    torch.save(Model.state_dict(), model_path)
    
    print("###############################")
    evaluate_model(Model, dataset_id=Dataset_Id, batch_size=PARAMETER_CONFIGURATION['batch_size'], validation_set=False)
    print("###############################")

'''
testSet:测试点目录
model: 加载的模型
'''


def test_localization_error(model, testSet, model_name):
    device = torch.device('cpu')
    model = model.to(device)

    model_path = os.path.join(PARAMETER_CONFIGURATION['model_save_path'], model_name)
    if os.path.exists(model_path):
        model.load_state_dict(torch.load(model_path, map_location=device))

    dot_name_list = ['A1', 'A2', 'A3', 'A4', 'B1', 'B2', 'B3', 'B4', 'C1', 'C2', 'C3', 'D1', 'D2', 'D3', 'D4', 'D5', 'E3', 'E4', 'F1', 'F3', 'F4']
    oridinate = pd.read_csv(PARAMETER_CONFIGURATION['oridinate_csv'])

    print('测试集目录：', testSet)

    distance_ERROR = []
    model.eval()
    wknn_x = []
    wknn_y = []
    for dot_name in dot_name_list:
        true_oridinate = oridinate[dot_name]
        true_X = true_oridinate[0]
        true_Y = true_oridinate[1]
        
        test_dot_num = 0

        for file in os.listdir(os.path.join(testSet, dot_name)):
            with torch.no_grad():
                test_dot_num += 1

                path = os.path.join(os.path.join(testSet, dot_name), file)
                rss = pd.read_csv(path)['RSS'].tolist()

                input_array = torch.tensor(rss, dtype=torch.float32)
                input_array = input_array.unsqueeze(0).unsqueeze(0)

                outputs = model(input_array)
                a = F.softmax(outputs, dim=-1)

                top_values, top_K_index = torch.topk(outputs, k=PARAMETER_CONFIGURATION['K_value'], dim=1)
                top_values = top_values.tolist()
                top_K_index = top_K_index.tolist()
                top_values = [item for sublist in top_values for item in sublist]
                top_K_index = [item for sublist in top_K_index for item in sublist]
                top_K_dot = []
                for index in top_K_index:
                    top_K_dot.append(dot_name_list[index])

                predic_oridinate_X = []
                predic_oridinate_Y = []
                for i in top_K_dot:
                    predic_oridinate_X.append(oridinate[i][0])
                    predic_oridinate_Y.append(oridinate[i][1])
                denominator = sum(top_values)
                weight = []
                for index in range(PARAMETER_CONFIGURATION['K_value']):
                    weight.append(top_values[index] / denominator)
                predic_X = 0
                predic_Y = 0
                for index in range(PARAMETER_CONFIGURATION['K_value']):
                    predic_X = predic_X + weight[index] * predic_oridinate_X[index]
                    predic_Y = predic_Y + weight[index] * predic_oridinate_Y[index]
                    wknn_x.append( predic_X )
                    wknn_y.append( predic_Y )
                distance_error = math.sqrt((true_X - predic_X) ** 2 + (true_Y - predic_Y) ** 2)

                distance_ERROR.append(distance_error)


    print(*wknn_x, sep='\n')
    print("---------------------------------------------------")
    print(*wknn_y,sep='\n')

    result = {}
    result[model_name] = distance_ERROR
    return result



def plot_CDF( distance_error ):
    for dict in distance_error:
        for key,distance_ERROR in dict.items():

            distance_ERROR.sort()
            cumulative_probability = []
            for i in distance_ERROR:
                num = 0
                for j in distance_ERROR:
                    if j<=i:
                        num = num + 1
                cumulative_probability.append( num / len(distance_ERROR) )
        plt.plot( distance_ERROR,cumulative_probability,label=key )
    plt.xlabel('distance error(m)')
    plt.ylabel('cumulative probability(%)')
    plt.legend()
    plt.show()

def plot_Distance_Error( distance_error ):

    categories = []
    average = []
    for dict in distance_error:
        for key,distance_ERROR in dict.items():
            categories.append( key )
            average.append( np.mean(distance_ERROR) )

    bar_width = 0.4

    custom_colors = ['r', 'g', 'b', 'c', 'm', 'y', 'k']
    plt.bar(categories,average,width=bar_width,color=custom_colors)

    for i , ave in enumerate(average):
        plt.text(i,ave+0.001,str(ave),ha='center',fontsize=10)

    plt.xlabel('K={}'.format(PARAMETER_CONFIGURATION['K_value']))
    plt.ylabel('distance error(m)')
    plt.show()

def print_average_error(distance_ERROR):
    mean_dict = {}
    for mod in distance_ERROR:
        for key,value in mod.items():
            mean_value = np.mean(value)
            mean_dict[key] = mean_value
            print( f"模型：{key} , 平均误差： {mean_value}" )


if __name__ == '__main__':
    
    distance_error = []
    device = torch.device('cpu')
    model = MixedModel(PARAMETER_CONFIGURATION['input_size'], PARAMETER_CONFIGURATION['num_classes'])
    model.to(device)

    #trained_model = train_model(model, 1, epochs=PARAMETER_CONFIGURATION['epochs'],batch_size=PARAMETER_CONFIGURATION['batch_size'],learning_rate=PARAMETER_CONFIGURATION['lr'],device=PARAMETER_CONFIGURATION['device'])

    #evaluate_model(trained_model)

    process_dataset(4, Model= model, model_name= 'Thesis_Origin.pth')

    distance_error.append(test_localization_error(model=model,testSet=PARAMETER_CONFIGURATION['testData'], model_name='Thesis_Origin.pth'))

    #print(distance_error)
    #print_average_error(distance_error)

    plot_CDF(distance_error)
    plot_Distance_Error(distance_error)
    

    '''distance_error = []

    process_dataset(4,
                    Model=MixedModel(PARAMETER_CONFIGURATION['input_size'], PARAMETER_CONFIGURATION['num_classes']),
                    model_name='Thesis_Origin.pth')

    distance_error.append(test_localization_error(
        model=MixedModel(PARAMETER_CONFIGURATION['input_size'], PARAMETER_CONFIGURATION['num_classes']),
        testSet=PARAMETER_CONFIGURATION['testData'],
        model_name='Thesis_Origin.pth')
    )

    print_average_error(distance_error)
    '''




