import math
import multiprocessing
import os
import time
import matplotlib
# 模型搭建
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import Adam
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch.utils.data import TensorDataset, DataLoader

class SqueezeExcitation(nn.Module):     #SE模块
    def __init__(self, in_channels):
        super(SqueezeExcitation, self).__init__()
        self.se = nn.Sequential(
            nn.AdaptiveAvgPool1d(1),
            nn.Conv1d(in_channels, in_channels // 8, 1),
            nn.ReLU(),
            nn.Conv1d(in_channels // 8, in_channels, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        a = self.se(x)
        return x * self.se(x)

'''
论文原始模型
'''
drop_0 = 0.3
drop_1 = 0.3
drop_2 = 0.2
drop_3 = 0.2
drop_4 = 0.3
drop_5 = 0.3

class MixedModel(nn.Module):
    def __init__(self, input_size, num_classes):
        super(MixedModel, self).__init__()
        self.conv0 = nn.Conv1d(input_size, 32, 3, padding=1)
        self.bn0 = nn.BatchNorm1d(32)
        self.dropout0 = nn.Dropout(drop_0)
        self.conv1 = nn.Conv1d(32, 64, 5, padding=2)
        self.bn1 = nn.BatchNorm1d(64)
        self.dropout1 = nn.Dropout(drop_1)
        self.lstm = nn.LSTM(64, 16, batch_first=True)
        self.dropout2 = nn.Dropout(drop_2)
        self.conv2 = nn.Conv1d(input_size, 64, 7, padding=3)
        self.bn2 = nn.BatchNorm1d(64)
        self.dropout3 = nn.Dropout(drop_3)
        self.se1 = SqueezeExcitation(64)
        self.conv3 = nn.Conv1d(64, 128, 5, padding=2)
        self.bn3 = nn.BatchNorm1d(128)
        self.dropout4 = nn.Dropout(drop_4)
        self.se2 = SqueezeExcitation(128)
        self.conv4 = nn.Conv1d(128, 64, 3, padding=1)
        self.bn4 = nn.BatchNorm1d(64)
        self.dropout5 = nn.Dropout(drop_5)
        self.gap = nn.AdaptiveAvgPool1d(1)
        self.fc = nn.Linear(16 + 64, num_classes)

    def forward(self, x):
        # Pre-LSTM Convolutional layers
        x_0 = x.permute(0, 2, 1)
        x0 = F.relu(self.bn0(self.conv0(x_0)))
        x0 = F.relu(self.bn1(self.conv1(x0)))
        # x0 = self.dropout1(x0)
        # LSTM branch
        x1, _ = self.lstm(x0.permute(0, 2, 1))
        x1 = self.dropout2(x1[:, -1, :])
        # CNN branch
        x2 = F.relu(self.bn2(self.conv2(x_0)))
        # x2 = self.dropout3(x2)
        x2 = self.se1(x2)
        x2 = F.relu(self.bn3(self.conv3(x2)))
        # x2 = self.dropout4(x2)
        x2 = self.se2(x2)
        x2 = F.relu(self.bn4(self.conv4(x2)))
        x2 = self.dropout5(x2)
        x2 = self.gap(x2).squeeze(-1)
        # Concatenate
        x = torch.cat([x1, x2], dim=-1)
        x = self.fc(x)

        return x

'''
卷积+LSTM
'''
class CnnLSTM(nn.Module):
    def __init__(self, input_size, num_classes):
        super(CnnLSTM, self).__init__()
        self.conv0 = nn.Conv1d(input_size, 64, 3, padding=1)
        self.bn0 = nn.BatchNorm1d(64)
        self.dropout0 = nn.Dropout(0.5)
        self.conv1 = nn.Conv1d(64, 128, 3, padding=1)
        self.bn1 = nn.BatchNorm1d(128)
        self.dropout1 = nn.Dropout(0.5)
        self.lstm = nn.LSTM(128, 8, batch_first=True)
        self.dropout2 = nn.Dropout(0.4)
        self.conv2 = nn.Conv1d(128, 128, 7, padding=3)
        self.bn2 = nn.BatchNorm1d(128)
        self.dropout3 = nn.Dropout(0.2)
        self.se1 = SqueezeExcitation(128)
        self.conv3 = nn.Conv1d(128, 256, 5, padding=2)
        self.bn3 = nn.BatchNorm1d(256)
        self.dropout4 = nn.Dropout(0.4)
        self.se2 = SqueezeExcitation(256)
        self.conv4 = nn.Conv1d(256, 128, 3, padding=1)
        self.bn4 = nn.BatchNorm1d(128)
        self.dropout5 = nn.Dropout(0.4)
        self.gap = nn.AdaptiveAvgPool1d(1)
        self.fc = nn.Linear(8, num_classes)

    def forward(self, x):
        # Pre-LSTM Convolutional layers
        x0 = x.permute(0, 2, 1)
        x0 = F.relu(self.bn0(self.conv0(x0)))
        x0 = F.relu(self.bn1(self.conv1(x0)))
        x0 = self.dropout1(x0)
        # LSTM branch
        x1, _ = self.lstm(x0.permute(0, 2, 1))
        x1 = self.dropout2(x1[:, -1, :])

        # Concatenate
        x = self.fc(x1)
        return x



